-- migrations/002_works.down.sql

START TRANSACTION;
DROP TABLE IF EXISTS `works`;
COMMIT;
